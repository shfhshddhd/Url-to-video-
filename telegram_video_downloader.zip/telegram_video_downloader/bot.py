import asyncio
import ipaddress
import logging
import os
import re
import shutil
import socket
import tempfile
import time
from pathlib import Path
from urllib.parse import urlparse

import requests
import yt_dlp
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ChatAction
from telegram.error import BadRequest, Forbidden, TelegramError
from telegram.ext import (
    Application, CallbackQueryHandler, CommandHandler, ContextTypes,
    MessageHandler, filters,
)

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=os.getenv("LOG_LEVEL", "INFO"),
)
log = logging.getLogger("video-bot")

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
# Conservative default for common hosted Bot API deployments. Adjust only after verifying
# the limits of the Bot API endpoint you use.
MAX_UPLOAD_MB = max(1, int(os.getenv("MAX_UPLOAD_MB", "49")))
MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024
MAX_DOWNLOAD_MB = max(1, int(os.getenv("MAX_DOWNLOAD_MB", "500")))
MAX_DOWNLOAD_BYTES = MAX_DOWNLOAD_MB * 1024 * 1024
WORK_DIR = Path(os.getenv("WORK_DIR", "/tmp/video-downloader"))
WORK_DIR.mkdir(parents=True, exist_ok=True)
URL_RE = re.compile(r"https?://[^\s<>]+", re.I)
USER_JOBS = {}
JOB_TTL = 30 * 60

def validate_url(url: str) -> str:
    url = url.strip().rstrip(".,);]}>")
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("Link HTTP/HTTPS hona chahiye.")
    if p.username or p.password:
        raise ValueError("Login credentials wale URLs supported nahi hain.")
    host = p.hostname.lower().rstrip(".")
    if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
        raise ValueError("Local/private address allowed nahi hai.")
    try:
        infos = socket.getaddrinfo(host, p.port or (443 if p.scheme == "https" else 80), type=socket.SOCK_STREAM)
        for info in infos:
            ip = ipaddress.ip_address(info[4][0])
            if not ip.is_global:
                raise ValueError("Private ya local network URL allowed nahi hai.")
    except socket.gaierror:
        # Some supported extractor URLs may resolve only during extraction. yt-dlp will
        # return a clear error if unreachable; direct downloads are checked again below.
        pass
    return url

def extract_info(url: str) -> dict:
    opts = {
        "quiet": True, "no_warnings": True, "skip_download": True,
        "noplaylist": True, "socket_timeout": 20, "retries": 1,
        "extractor_retries": 1, "ignoreerrors": False,
    }
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=False)
    if not info:
        raise ValueError("Video metadata nahi mili.")
    if info.get("_type") in ("playlist", "multi_video") or info.get("entries"):
        raise ValueError("Playlist nahi, ek single video URL bhejein.")
    formats = []
    seen = set()
    for f in info.get("formats") or []:
        if f.get("vcodec") in (None, "none"):
            continue
        height = f.get("height")
        if not height:
            continue
        ext = f.get("ext") or "mp4"
        # Prefer MP4 where possible, but keep distinct height/format options.
        size = f.get("filesize") or f.get("filesize_approx")
        key = (height, ext, f.get("format_id"))
        if key in seen:
            continue
        seen.add(key)
        formats.append({
            "format_id": str(f.get("format_id")),
            "height": int(height),
            "ext": ext,
            "size": int(size) if size else None,
            "format_note": f.get("format_note") or "",
            "has_audio": f.get("acodec") not in (None, "none"),
        })
    # Collapse to one best option per resolution; prefer audio-included and known size.
    by_height = {}
    for f in formats:
        h = f["height"]
        old = by_height.get(h)
        score = (bool(f["has_audio"]), bool(f["size"]), f["ext"] == "mp4")
        old_score = (bool(old and old["has_audio"]), bool(old and old["size"]), bool(old and old["ext"] == "mp4"))
        if old is None or score > old_score:
            by_height[h] = f
    formats = sorted(by_height.values(), key=lambda x: x["height"], reverse=True)
    if not formats:
        # Direct downloadable files may not expose height metadata; provide a single
        # original-quality option after probing the content length.
        formats = [{"format_id": "best", "height": 0, "ext": "mp4", "size": None, "format_note": "Original", "has_audio": True}]
    return {
        "title": str(info.get("title") or "Video")[:180],
        "duration": info.get("duration"),
        "thumbnail": info.get("thumbnail"),
        "webpage_url": info.get("webpage_url") or url,
        "formats": formats[:12],
    }

def fmt_size(size):
    if not size:
        return "size unknown"
    return f"{size / (1024 * 1024):.1f} MB"

def fmt_duration(seconds):
    if not seconds:
        return "Unknown"
    seconds = int(seconds)
    return f"{seconds//3600:02}:{(seconds%3600)//60:02}:{seconds%60:02}" if seconds >= 3600 else f"{seconds//60:02}:{seconds%60:02}"

def get_job(uid, jid):
    job = USER_JOBS.get(uid)
    if not job or job["id"] != jid or time.time() - job["created"] > JOB_TTL:
        return None
    return job

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🎬 *Video Downloader*\n\nKisi supported website ka video URL ya direct MP4/WebM link bhejo. "
        "Main available quality aur size check karke buttons dikhaunga.\n\n"
        "Commands: /start, /help, /cancel\n\n"
        "Note: Login/DRM-protected ya unsupported links download nahi honge.",
        parse_mode="Markdown",
    )

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start(update, context)

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    USER_JOBS.pop(update.effective_user.id, None)
    await update.message.reply_text("Current selection cancel kar di gayi.")

async def receive_url(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text or ""
    match = URL_RE.search(text)
    if not match:
        await update.message.reply_text("Valid video URL bhejein, jaise https://...")
        return
    try:
        url = validate_url(match.group(0))
    except ValueError as e:
        await update.message.reply_text(f"❌ {e}")
        return
    msg = await update.message.reply_text("🔎 Link check kar raha hoon…")
    try:
        info = await asyncio.to_thread(extract_info, url)
        uid = update.effective_user.id
        jid = str(int(time.time() * 1000))
        USER_JOBS[uid] = {"id": jid, "created": time.time(), "url": url, "info": info}
        buttons = []
        for i, f in enumerate(info["formats"]):
            quality = f'{f["height"]}p' if f["height"] else "Original quality"
            size = fmt_size(f["size"])
            buttons.append([InlineKeyboardButton(f"📥 {quality} · {size}", callback_data=f"q:{jid}:{i}")])
        caption = (
            f"🎞 *{escape_md(info['title'])}*\n"
            f"⏱ Duration: {fmt_duration(info.get('duration'))}\n"
            f"📺 Available qualities: {len(info['formats'])}\n\n"
            "Download quality choose karein:"
        )
        thumb = info.get("thumbnail")
        if thumb:
            try:
                # Only fetch small public image thumbnails; never trust arbitrary file URLs.
                await asyncio.to_thread(download_thumbnail, thumb, WORK_DIR / f"thumb_{uid}_{jid}.jpg")
                path = WORK_DIR / f"thumb_{uid}_{jid}.jpg"
                with path.open("rb") as fp:
                    await msg.delete()
                    await update.message.reply_photo(photo=fp, caption=caption, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(buttons))
                path.unlink(missing_ok=True)
                return
            except Exception as e:
                log.info("Thumbnail unavailable: %s", e)
        await msg.edit_text(caption, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(buttons))
    except Exception as e:
        log.warning("Metadata extraction failed: %s", e)
        await msg.edit_text("❌ Video available nahi hai ya website supported nahi hai.\n\n"
                            "Link public hona chahiye. Login, DRM, expired links aur private videos supported nahi hain.")

def escape_md(value):
    # Telegram Markdown v1 escaping
    return re.sub(r"([_*`\[])", r"\\\1", str(value))

def download_thumbnail(url, path):
    # SSRF guard for thumbnail URL as well.
    url = validate_url(url)
    r = requests.get(url, timeout=12, stream=True, headers={"User-Agent": "Mozilla/5.0"})
    r.raise_for_status()
    ctype = r.headers.get("content-type", "")
    if not ctype.startswith("image/"):
        raise ValueError("Thumbnail is not an image")
    total = 0
    with open(path, "wb") as f:
        for chunk in r.iter_content(8192):
            total += len(chunk)
            if total > 4 * 1024 * 1024:
                raise ValueError("Thumbnail too large")
            f.write(chunk)

async def choose_quality(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    try:
        _, jid, idx = q.data.split(":")
        job = get_job(q.from_user.id, jid)
        if not job:
            await q.edit_message_caption(caption="Selection expire ho gayi. URL dobara bhejein.")
            return
        f = job["info"]["formats"][int(idx)]
        job["format"] = f
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🎬 Video", callback_data=f"d:{jid}:video"),
             InlineKeyboardButton("📎 Document", callback_data=f"d:{jid}:document")],
            [InlineKeyboardButton("❌ Cancel", callback_data=f"x:{jid}")],
        ])
        text = f"Quality: {f['height']}p" if f["height"] else "Quality: Original"
        text += f"\nEstimated size: {fmt_size(f['size'])}\n\nDelivery type choose karein:"
        if q.message.photo:
            await q.edit_message_caption(caption=text, reply_markup=kb)
        else:
            await q.edit_message_text(text, reply_markup=kb)
    except Exception as e:
        log.exception("Quality callback failed")
        await q.edit_message_text("Selection process nahi ho saka. URL dobara bhejein.")

async def deliver(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    try:
        _, jid, mode = q.data.split(":")
        job = get_job(q.from_user.id, jid)
        if not job:
            await q.edit_message_caption(caption="Selection expire ho gayi. URL dobara bhejein.")
            return
        f = job["format"]
        status = await q.message.reply_text("⬇️ Download shuru ho raha hai…")
        loop = asyncio.get_running_loop()
        last_update = [0.0]
        def hook(d):
            now = time.time()
            if now - last_update[0] < 3 and d.get("status") != "finished":
                return
            last_update[0] = now
            if d.get("status") == "downloading":
                total = d.get("total_bytes") or d.get("total_bytes_estimate")
                got = d.get("downloaded_bytes", 0)
                pct = int(got * 100 / total) if total else 0
                text = f"⬇️ Download: {pct}% ({got/1048576:.1f} MB)"
            elif d.get("status") == "finished":
                text = "📤 Download complete. Telegram par upload kar raha hoon…"
            else:
                return
            asyncio.run_coroutine_threadsafe(status.edit_text(text), loop)
        with tempfile.TemporaryDirectory(dir=WORK_DIR) as td:
            opts = {
                "outtmpl": str(Path(td) / "%(title).100B.%(ext)s"),
                "noplaylist": True, "quiet": True, "no_warnings": True,
                "socket_timeout": 25, "retries": 2, "progress_hooks": [hook],
                "max_filesize": MAX_DOWNLOAD_BYTES,
                "merge_output_format": "mp4",
            }
            if f["format_id"] == "best":
                opts["format"] = "best[protocol^=http]/best"
            else:
                opts["format"] = f["format_id"]
            await asyncio.to_thread(run_download, job["url"], opts)
            files = [p for p in Path(td).iterdir() if p.is_file() and not p.name.endswith((".part", ".ytdl"))]
            if not files:
                raise ValueError("Download file create nahi hui.")
            file_path = max(files, key=lambda p: p.stat().st_size)
            size = file_path.stat().st_size
            if size > MAX_UPLOAD_BYTES:
                await status.edit_text(
                    f"❌ File {size/1048576:.1f} MB hai, configured Telegram limit {MAX_UPLOAD_MB} MB hai. "
                    "Lower quality select karein ya apne verified Bot API setup ke mutabik MAX_UPLOAD_MB badlein."
                )
                return
            await status.edit_text("📤 Telegram par upload ho raha hai…")
            title = job["info"]["title"][:900]
            with file_path.open("rb") as fp:
                if mode == "video":
                    await q.message.reply_video(video=fp, caption=title, supports_streaming=True, read_timeout=180, write_timeout=180, connect_timeout=30)
                else:
                    await q.message.reply_document(document=fp, filename=file_path.name, caption=title, read_timeout=180, write_timeout=180, connect_timeout=30)
            await status.edit_text("✅ Video successfully bhej diya.")
            USER_JOBS.pop(q.from_user.id, None)
    except yt_dlp.utils.DownloadError as e:
        log.warning("Download failed: %s", e)
        await q.message.reply_text("❌ Download fail hua. Link expired, unsupported, login-protected, ya selected format unavailable ho sakta hai.")
    except (BadRequest, Forbidden) as e:
        log.warning("Telegram rejected upload: %s", e)
        await q.message.reply_text("❌ Telegram upload reject hua. File size, bot permissions, ya Telegram API limit check karein.")
    except Exception as e:
        log.exception("Delivery failed")
        await q.message.reply_text("❌ Error aaya. URL dobara try karein ya lower quality choose karein.")
    finally:
        try:
            await q.message.delete()
        except Exception:
            pass

def run_download(url, opts):
    with yt_dlp.YoutubeDL(opts) as ydl:
        ydl.download([url])

async def cancel_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer("Cancelled")
    USER_JOBS.pop(q.from_user.id, None)
    try:
        await q.edit_message_caption(caption="❌ Cancelled.")
    except BadRequest:
        await q.edit_message_text("❌ Cancelled.")

async def unknown_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer("Button expire ho gaya. URL dobara bhejein.", show_alert=True)

def main():
    if not TOKEN:
        raise SystemExit("TELEGRAM_BOT_TOKEN environment variable set nahi hai.")
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("cancel", cancel))
    app.add_handler(CallbackQueryHandler(choose_quality, pattern=r"^q:"))
    app.add_handler(CallbackQueryHandler(deliver, pattern=r"^d:"))
    app.add_handler(CallbackQueryHandler(cancel_button, pattern=r"^x:"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, receive_url))
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
