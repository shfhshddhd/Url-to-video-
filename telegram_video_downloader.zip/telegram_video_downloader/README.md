# Telegram Video Downloader Bot

Python Telegram bot that extracts metadata from supported public video URLs using `yt-dlp`, displays thumbnail/title/duration and available quality buttons, and sends the selected download as a Telegram video or document.

## Features
- Supports many public websites supported by `yt-dlp`, plus direct HTTP(S) media links where metadata is accessible.
- Thumbnail preview and available resolution buttons.
- Shows exact size when source metadata provides it; otherwise displays `size unknown` because exact size is not known until download.
- Video or document delivery.
- Download progress, URL checks, single-video-only handling, temporary directories and errors.
- Conservative configurable upload/download size limits.

## Important limitations
- No downloader can support literally every URL. Login-required, private, expired, DRM-protected or unsupported links may fail.
- This bot does not bypass DRM, paywalls, access controls, or private content restrictions. Use only content you have permission to download.
- GitHub Actions is for temporary testing, not permanent hosting. The workflow stops after 350 minutes. Start it manually again when needed.
- `MAX_UPLOAD_MB=49` is a conservative default for common hosted Bot API usage; verify the actual limits of the Telegram Bot API endpoint you use before changing it. Large uploads can fail even when the runner has enough disk.
- Some sources provide approximate sizes only. The bot labels unavailable sizes as unknown instead of inventing an exact MB value.
- GitHub scheduled workflows are not guaranteed to start at an exact minute and may be disabled for inactive repositories.
- Never commit your bot token.

## Setup on GitHub
1. Create a new repository and upload these files.
2. In **Settings → Secrets and variables → Actions → New repository secret**, add:
   - Name: `TELEGRAM_BOT_TOKEN`
   - Value: your token from BotFather
3. Optional: in **Settings → Secrets and variables → Actions → Variables**, add `MAX_UPLOAD_MB` and `MAX_DOWNLOAD_MB`. Keep the upload limit conservative.
4. Open **Actions → Video Downloader Bot → Run workflow**.
5. Open your bot in Telegram and send `/start`, then a public video URL.
6. To stop the test, cancel the workflow run in Actions.

## Run locally
```bash
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
pip install -r requirements.txt
export TELEGRAM_BOT_TOKEN="YOUR_TOKEN"
python bot.py
```

## Safety
The bot rejects local/private-network URLs as an SSRF precaution and does not accept URLs with embedded usernames/passwords. Keep dependencies updated. Only download material you are authorized to access.
